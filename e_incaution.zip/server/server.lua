ESX = exports["es_extended"]:getSharedObject()

RegisterServerEvent('incautar:checkJob')
AddEventHandler('incautar:checkJob', function(playerId, vehicle)
    local xPlayer = ESX.GetPlayerFromId(playerId)
    if xPlayer.job.name == 'police' then
        TriggerClientEvent('incautar:incautarCoche', playerId, vehicle)
    else
        TriggerClientEvent('chat:addMessage', playerId, { args = { 'Sistema', 'No tienes permiso para incautar coches.' } })
    end
end)

RegisterServerEvent('incautar:sendToDepot')
AddEventHandler('incautar:sendToDepot', function(vehicleCoords)
    local plate = GetVehicleNumberPlateText(vehicle)
    MySQL.Async.execute('INSERT INTO vehicle_depot (plate, coords) VALUES (@plate, @coords)', {
        ['@plate'] = plate,
        ['@coords'] = json.encode(vehicleCoords)
    })
end)

RegisterServerEvent('incautar:getImpoundedVehicles')
AddEventHandler('incautar:getImpoundedVehicles', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    MySQL.Async.fetchAll('SELECT * FROM vehicle_depot WHERE owner = @owner', {
        ['@owner'] = xPlayer.identifier
    }, function(result)
        TriggerClientEvent('incautar:openRecoveryMenu', source, result)
    end)
end)

RegisterServerEvent('incautar:recoverVehicle')
AddEventHandler('incautar:recoverVehicle', function(vehicleId)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.getMoney() >= recoveryFee then
        xPlayer.removeMoney(recoveryFee)
        MySQL.Async.fetchAll('SELECT * FROM vehicle_depot WHERE id = @id AND owner = @owner', {
            ['@id'] = vehicleId,
            ['@owner'] = xPlayer.identifier
        }, function(result)
            if result[1] then
                local vehicleCoords = json.decode(result[1].coords)
                TriggerClientEvent('esx:spawnVehicle', source, 'adder', vehicleCoords)
                MySQL.Async.execute('DELETE FROM vehicle_depot WHERE id = @id', {
                    ['@id'] = vehicleId
                })
            end
        end)
    else
        TriggerClientEvent('chat:addMessage', source, { args = { 'Sistema', 'No tienes suficiente dinero para recuperar tu coche.' } })
    end
end)
