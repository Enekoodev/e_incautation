fx_version 'cerulean'
game 'gta5'

author 'LSE Network & Eneko'
description 'Script de Incautacion de Coches by LSE Network (Aun hay funciones en desarollo)'
version '1.0.0'

shared_scripts {
    '@es_extended/locale.lua'
}

client_scripts {
    '@ox_target/client.lua',
    '@es_extended/client/functions.lua',
    'client/incautar_coches.lua'
}

server_scripts {
    '@mysql-async/lib/MySQL.lua',
    '@es_extended/locale.lua',
    'server/server.lua'
}

dependencies {
    'es_extended',
    'ox_target',
    'mysql-async',
    'esx_menu_default'
}
