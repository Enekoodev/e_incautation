local depositLocation = vector3(123.4, 456.7, 789.0) -- Cambiar por tus coords pero aun no ya que esta en desarollo
local recoveryFee = 500

-- Agrega el objetivo de ox_target para incautar coches
exports.ox_target:addGlobalVehicle({
    {
        name = 'incautar_coche',
        icon = 'fas fa-car-crash',
        label = 'Incautar coche',
        canInteract = function(entity, distance, coords, name, bone)
            local playerPed = PlayerPedId()
            if distance < 2.0 and not IsPedInAnyVehicle(playerPed, false) then
                return true
            end
            return false
        end,
        onSelect = function(data)
            local playerPed = PlayerPedId()
            local vehicle = data.entity
            if not IsPedInAnyVehicle(playerPed, false) and DoesEntityExist(vehicle) then
                local playerId = GetPlayerServerId(PlayerId())
                TriggerServerEvent('incautar:checkJob', playerId, vehicle)
            end
        end
    }
})

function playSeizeAnimation()
    local playerPed = PlayerPedId()
    RequestAnimDict('mini@repair')
    while not HasAnimDictLoaded('mini@repair') do
        Citizen.Wait(100)
    end
    TaskPlayAnim(playerPed, 'mini@repair', 'fixing_a_ped', 8.0, -8.0, 5000, 1, 0, false, false, false)
    Citizen.Wait(5000) -- 5 s
    ClearPedTasks(playerPed)
end

RegisterNetEvent('incautar:incautarCoche')
AddEventHandler('incautar:incautarCoche', function(vehicle)
    if DoesEntityExist(vehicle) then
        playSeizeAnimation()
        local vehicleCoords = GetEntityCoords(vehicle)
        DeleteEntity(vehicle)
        TriggerServerEvent('incautar:sendToDepot', vehicleCoords)
    end
end)

RegisterNetEvent('incautar:openRecoveryMenu')
AddEventHandler('incautar:openRecoveryMenu', function(vehicles)
    local elements = {}
    for _, vehicle in ipairs(vehicles) do
        table.insert(elements, {
            label = ('%s - $%s'):format(vehicle.plate, recoveryFee),
            value = vehicle.id
        })
    end

    ESX.UI.Menu.CloseAll()

    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'recovery_menu', {
        title    = 'Recuperar Coches Incautados',
        align    = 'top-left',
        elements = elements
    }, function(data, menu)
        local vehicleId = data.current.value
        TriggerServerEvent('incautar:recoverVehicle', vehicleId)
        menu.close()
    end, function(data, menu)
        menu.close()
    end)
end)

-- Target para el NPC del depósito (Trabajando aun)
exports.ox_target:addBoxZone({
    name = 'deposito_npc',
    coords = depositLocation,
    size = vec3(1, 1, 2),
    rotation = 0,
    debugPoly = false,
    options = {
        {
            icon = 'fas fa-dollar-sign',
            label = 'Recuperar coche incautado',
            action = function()
                TriggerServerEvent('incautar:getImpoundedVehicles')
            end
        }
    }
})


Citizen.CreateThread(function()
    RequestModel(GetHashKey('s_m_m_security_01'))
    while not HasModelLoaded(GetHashKey('s_m_m_security_01')) do
        Wait(1)
    end

    local npc = CreatePed(4, GetHashKey('s_m_m_security_01'), depositLocation.x, depositLocation.y, depositLocation.z, 0.0, false, true)
    SetEntityHeading(npc, 0.0)
    FreezeEntityPosition(npc, true)
    SetEntityInvincible(npc, true)
    SetBlockingOfNonTemporaryEvents(npc, true)
end)

